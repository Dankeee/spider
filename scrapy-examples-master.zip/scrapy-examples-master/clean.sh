find . -name '*.pyc' | xargs rm
