#!/usr/bin/env python

"""parseli (save, rows o' json, and time)"""

__version__ = "0.0.5"
__author__ = [
    "Mek <michael.karpeles@gmail.com>"
]
__license__ = "public domain"
__contributors__ = "see AUTHORS"

from parseli import getli, crawli, parseli, company_search, people_search, custom_search
