import MySQLdb

def get_key_from_mysql():
    con = MySQLdb.connect(
            host = '127.0.0.1',
            port = 3306,
            db = 'linkedindb',
            user = 'root',
            passwd = 'bupt123456',
            )
    cur = conn.cursor()
    names = []
    names = cur.execute("select name from linkedinfo where tag = 0")
    cur.close()
    conn.commit()
    conn.close()
    return name
