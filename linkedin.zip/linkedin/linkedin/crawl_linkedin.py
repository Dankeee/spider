import re
import pandas as pn
import time
from selenium import webdriver
from linkedin.items import LinkedinItem#, LinkedinItem_detalle
from selenium import webdriver
from string import lower


def get_profile_data(driver,url):
    driver.get(url)
    item = LinkedinItem()
    #item = LinkedinItem_detalle()
    print("get in url")
    try:
        
        try:
            driver.find_element_by_class_name("more-text").click()
        except:
            pass

        
        
        try:
            editable_item = driver.find_element_by_class_name("editable-item")
            try:
                location = editable_item.find_element_by_xpath('//span[@class="locality"]').text
                item["location"] = location
                industry = editable_item.find_element_by_xpath('//dd[@class="industry"]').text
                item["industry"] = industry
            except:
                pass            
        except:
            pass

        try:
            item["full_content"] = None
            full_content = driver.find_element_by_class_name("summary").text
            item["full_content"] = full_content
        except:
            pass

        #current_job
        try:
            item['current_job'] = None
            current = driver.find_elements_by_xpath('//div[@id="background-experience"]//div[@class="editable-item section-item current-position"]')
            for each in current:
                string = each.text
        except:
            pass
        
        #past experience
        

        try:
            past = driver.find_elements_by_xpath('//div[@id="background-experience"]//div[@class="editable-item section-item past-position"]')
            item["job_0"] = None
            item["job_1"] = None
            item["job_2"] = None
            item["job_3"] = None
            item["job_4"] = None
        
            i = 0
            for each in past:
                string = each.text
                item["job_{0}".format(i)] = string
                i += 1
                if i>4:
                    break
        except:
            pass

        
        #skills
        try:
            item["skills"] = None
            item["skills_2"] = None
            item["skills"] = driver.find_element_by_class_name("skills-section").text
            item["skills_2"] = driver.find_element_by_css_selector(".compact-view").text
        except:
            pass

        #education
        try:
            item["education_sum"] = None
            item["education_tot"] = None
            item["education_sum"] = driver.find_element_by_id("overview-summary-education").text
            item["education_tot"] = driver.find_element_by_id("background-education").text
        except:
            pass


        try:
            item["personal"] = None
            item["personal"] = driver.find_element_by_id("personal-info-view").text
        except:
            pass
        driver.back()
        print("success get back")
        return item

    except:
        item = {'industry':None,'current_job':None,'job_0':None,'job_1':None,'job_2':None,'job_3':None,'job_4':None,'full_content':None,'skills':None,'skills_2':None,'education_sum':None,'education_tot':None,'personal':None}
        driver.back()
        print("defult get back")
        return item


