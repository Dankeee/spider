# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# http://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class LinkedinItem(scrapy.Item):
    # define the fields for your item here like:
    url = scrapy.Field()
    name = scrapy.Field()
    description = scrapy.Field()    
    location = scrapy.Field()
    similar = scrapy.Field()
    profile_img_s = scrapy.Field()
    industry = scrapy.Field()
    skills_2 = scrapy.Field()
    skills = scrapy.Field()
    current_job =scrapy.Field()
    job_0 = scrapy.Field()
    job_1 = scrapy.Field()
    job_2 = scrapy.Field()
    job_3 = scrapy.Field()
    job_4 = scrapy.Field()
    education_sum = scrapy.Field()
    education_tot = scrapy.Field()
    full_content = scrapy.Field()
    personal = scrapy.Field()
    key = scrapy.Field()

    pass

'''class LinkedinItem_detalle(scrapy.Item):
    # define the fields for your item here like:
    skills_2 = scrapy.Field()
    skills = scrapy.Field()
    job_0 = scrapy.Field()
    job_1 = scrapy.Field()
    job_2 = scrapy.Field()
    job_3 = scrapy.Field()
    job_4 = scrapy.Field()
    education_sum = scrapy.Field()
    education_tot = scrapy.Field()
    full_content = scrapy.Field()
    #personal = scrapy.Field()
    pass
'''

